# SG Money Tracker (Android starter)

A personal income/expense tracker built with React, TypeScript, Vite and Capacitor. The current starter stores transactions in the app's local browser storage so it works offline after the app is installed and opened. It does **not** sync to a bank or cloud.

## Features
- Income, expense, opening balance and available balance
- Add, edit and delete transactions
- Categories, dates, optional notes
- Monthly income/expense/net overview
- Search and filter transaction history
- Export transactions as CSV
- Dark and light themes
- INR currency formatting

## Requirements
- Node.js LTS (20 or newer recommended)
- Android Studio with Android SDK installed
- Java JDK compatible with your installed Android Gradle Plugin

## Run in browser
```bash
npm install
npm run dev
```
Open the local URL shown by Vite.

## Build Android APK
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
Android Studio opens the project. Wait for Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The APK is typically created under `android/app/build/outputs/apk/debug/`.

After making web-code changes:
```bash
npm run build
npx cap sync android
```
Then rebuild the APK in Android Studio.

## Data and backup notes
- Records are saved locally on the device/browser profile. Clearing app data or uninstalling the app may erase records.
- Export CSV regularly as a backup. CSV export contains transactions but does not include the opening balance or theme preference.
- This starter does not include PIN/biometric lock, cloud sync, encrypted backup, or SQLite.
- Do not use this as a bank ledger until you have tested calculations and backup/restore behavior with sample data.
- Google Fonts are optional styling; if unavailable, system fonts are used.
