import { useEffect, useMemo, useState } from 'react'
import { ArrowDownLeft, ArrowUpRight, Wallet, Plus, Trash2, Pencil, X, Moon, Sun, Search, CalendarDays, Download, TrendingUp } from 'lucide-react'

type TxType = 'income' | 'expense'
type Transaction = { id: string; type: TxType; amount: number; category: string; date: string; note: string }
const KEY = 'sg-money-tracker-transactions-v1'
const THEME_KEY = 'sg-money-tracker-theme-v1'
const incomeCategories = ['Salary', 'Trading Profit', 'Freelance', 'Gift', 'Other Income']
const expenseCategories = ['Food', 'Travel', 'Bills', 'Shopping', 'Health', 'Entertainment', 'Other Expense']
const today = () => new Date().toISOString().slice(0, 10)
const money = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(n)

function loadTransactions(): Transaction[] {
  try {
    const value = localStorage.getItem(KEY)
    return value ? JSON.parse(value) as Transaction[] : []
  } catch { return [] }
}

export default function App() {
  const [transactions, setTransactions] = useState<Transaction[]>(loadTransactions)
  const [theme, setTheme] = useState<'dark' | 'light'>(() => localStorage.getItem(THEME_KEY) === 'light' ? 'light' : 'dark')
  const [type, setType] = useState<TxType>('expense')
  const [amount, setAmount] = useState('')
  const [category, setCategory] = useState('Food')
  const [date, setDate] = useState(today())
  const [note, setNote] = useState('')
  const [openingBalance, setOpeningBalance] = useState(() => localStorage.getItem('sg-money-tracker-opening-balance-v1') ?? '0')
  const [filter, setFilter] = useState<'all' | TxType>('all')
  const [query, setQuery] = useState('')
  const [month, setMonth] = useState(today().slice(0, 7))
  const [editingId, setEditingId] = useState<string | null>(null)
  const [showForm, setShowForm] = useState(false)

  useEffect(() => { localStorage.setItem(KEY, JSON.stringify(transactions)) }, [transactions])
  useEffect(() => { localStorage.setItem('sg-money-tracker-opening-balance-v1', openingBalance) }, [openingBalance])
  useEffect(() => { localStorage.setItem(THEME_KEY, theme); document.documentElement.dataset.theme = theme }, [theme])

  const totalIncome = useMemo(() => transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0), [transactions])
  const totalExpense = useMemo(() => transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0), [transactions])
  const balance = Number(openingBalance || 0) + totalIncome - totalExpense
  const monthTransactions = transactions.filter(t => t.date.slice(0, 7) === month)
  const monthIncome = monthTransactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0)
  const monthExpense = monthTransactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0)
  const visibleTransactions = [...transactions]
    .filter(t => filter === 'all' || t.type === filter)
    .filter(t => `${t.category} ${t.note}`.toLowerCase().includes(query.toLowerCase()))
    .sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id))

  function resetForm() {
    setAmount(''); setCategory(type === 'income' ? incomeCategories[0] : expenseCategories[0])
    setDate(today()); setNote(''); setEditingId(null); setShowForm(false)
  }
  function startAdd(nextType: TxType) {
    setType(nextType); setCategory(nextType === 'income' ? incomeCategories[0] : expenseCategories[0])
    setAmount(''); setDate(today()); setNote(''); setEditingId(null); setShowForm(true)
  }
  function saveTransaction(e: React.FormEvent) {
    e.preventDefault()
    const parsedAmount = Number(amount)
    if (!Number.isFinite(parsedAmount) || parsedAmount <= 0) { alert('Enter an amount greater than zero.'); return }
    const item: Transaction = { id: editingId ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`, type, amount: Math.round(parsedAmount * 100) / 100, category, date, note: note.trim() }
    setTransactions(old => editingId ? old.map(t => t.id === editingId ? item : t) : [item, ...old])
    resetForm()
  }
  function editTransaction(t: Transaction) {
    setType(t.type); setAmount(String(t.amount)); setCategory(t.category); setDate(t.date); setNote(t.note); setEditingId(t.id); setShowForm(true)
  }
  function deleteTransaction(id: string) {
    if (confirm('Delete this transaction? This cannot be undone.')) setTransactions(old => old.filter(t => t.id !== id))
  }
  function exportCsv() {
    const rows = [['Date', 'Type', 'Category', 'Amount', 'Note'], ...transactions.map(t => [t.date, t.type, t.category, String(t.amount), t.note])]
    const csv = rows.map(row => row.map(v => `"${v.replaceAll('"', '""')}"`).join(',')).join('\\r\\n')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob); const a = document.createElement('a')
    a.href = url; a.download = `sg-money-tracker-${today()}.csv`; a.click(); URL.revokeObjectURL(url)
  }

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand-mark"><Wallet size={23} /></div>
      <div className="brand"><strong>SG Money Tracker</strong><span>Your money, clearly tracked.</span></div>
      <button className="icon-button" aria-label="Toggle theme" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? <Sun size={19} /> : <Moon size={19} />}</button>
    </header>

    <main>
      <section className="balance-card">
        <div className="balance-heading"><span>Available balance</span><span className="live-dot">● Local</span></div>
        <h1>{money(balance)}</h1>
        <p>Opening balance + income − expenses</p>
        <label className="opening-balance">Opening balance <span>₹ <input aria-label="Opening balance" type="number" min="0" value={openingBalance} onChange={e => setOpeningBalance(e.target.value)} /></span></label>
        <div className="balance-decoration"><TrendingUp size={92} /></div>
      </section>

      <section className="summary-grid">
        <article className="summary-card income-card"><div className="summary-icon"><ArrowDownLeft size={19} /></div><span>Total income</span><strong>{money(totalIncome)}</strong><small>All recorded income</small></article>
        <article className="summary-card expense-card"><div className="summary-icon"><ArrowUpRight size={19} /></div><span>Total expenses</span><strong>{money(totalExpense)}</strong><small>All recorded expenses</small></article>
      </section>

      <section className="quick-actions">
        <button className="action-button add-income" onClick={() => startAdd('income')}><span><Plus size={20} /></span><div><strong>Add income</strong><small>Record money received</small></div></button>
        <button className="action-button add-expense" onClick={() => startAdd('expense')}><span><Plus size={20} /></span><div><strong>Add expense</strong><small>Record money spent</small></div></button>
      </section>

      <section className="month-panel">
        <div className="section-title"><div><h2>Monthly overview</h2><p>Income and spending by month</p></div><label className="month-picker"><CalendarDays size={16} /><input aria-label="Select month" type="month" value={month} onChange={e => setMonth(e.target.value)} /></label></div>
        <div className="month-stats">
          <div><span>Income</span><strong className="positive">{money(monthIncome)}</strong></div>
          <div><span>Expenses</span><strong className="negative">{money(monthExpense)}</strong></div>
          <div><span>Net</span><strong className={monthIncome - monthExpense >= 0 ? 'positive' : 'negative'}>{money(monthIncome - monthExpense)}</strong></div>
        </div>
        <div className="progress-track"><div className="progress-fill" style={{ width: `${monthIncome + monthExpense ? Math.min(100, monthExpense / (monthIncome + monthExpense) * 100) : 0}%` }} /></div>
        <div className="progress-caption"><span>Expenses compared with total activity</span><strong>{monthIncome + monthExpense ? Math.round(monthExpense / (monthIncome + monthExpense) * 100) : 0}%</strong></div>
      </section>

      <section className="transactions-section">
        <div className="section-title"><div><h2>Transactions</h2><p>{transactions.length} total records</p></div><button className="export-button" onClick={exportCsv} disabled={!transactions.length}><Download size={16} /> Export CSV</button></div>
        <div className="filters"><div className="search-box"><Search size={17} /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search category or note" /></div>
          <div className="filter-tabs">{(['all', 'income', 'expense'] as const).map(f => <button key={f} className={filter === f ? 'selected' : ''} onClick={() => setFilter(f)}>{f === 'all' ? 'All' : f === 'income' ? 'Income' : 'Expenses'}</button>)}</div>
        </div>
        <div className="transaction-list">
          {visibleTransactions.length === 0 ? <div className="empty-state"><div className="empty-icon"><Wallet size={24} /></div><strong>No transactions yet</strong><p>Add your first income or expense to get started.</p></div> :
          visibleTransactions.map(t => <article className="transaction-row" key={t.id}><div className={`transaction-icon ${t.type}`} >{t.type === 'income' ? <ArrowDownLeft size={19} /> : <ArrowUpRight size={19} />}</div><div className="transaction-info"><strong>{t.category}</strong><span>{t.note || (t.type === 'income' ? 'Money received' : 'Money spent')} · {new Date(`${t.date}T12:00:00`).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</span></div><div className="transaction-right"><strong className={t.type === 'income' ? 'positive' : 'negative'}>{t.type === 'income' ? '+' : '−'}{money(t.amount)}</strong><div className="row-actions"><button aria-label="Edit transaction" onClick={() => editTransaction(t)}><Pencil size={14} /></button><button aria-label="Delete transaction" onClick={() => deleteTransaction(t.id)}><Trash2 size={14} /></button></div></div></article>)}
        </div>
      </section>
      <footer>SG Money Tracker <span>•</span> Your records stay on this device</footer>
    </main>

    {showForm && <div className="modal-backdrop" onClick={e => { if (e.target === e.currentTarget) resetForm() }}><form className="transaction-modal" onSubmit={saveTransaction}>
      <div className="modal-heading"><div><h2>{editingId ? 'Edit transaction' : type === 'income' ? 'Add income' : 'Add expense'}</h2><p>Enter the transaction details below.</p></div><button type="button" className="icon-button" onClick={resetForm} aria-label="Close"><X size={20} /></button></div>
      <div className="type-switch"><button type="button" className={type === 'income' ? 'active income-active' : ''} onClick={() => { setType('income'); setCategory(incomeCategories[0]) }}>Income</button><button type="button" className={type === 'expense' ? 'active expense-active' : ''} onClick={() => { setType('expense'); setCategory(expenseCategories[0]) }}>Expense</button></div>
      <label className="form-label">Amount (₹)<input autoFocus type="number" min="0.01" step="0.01" placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value)} required /></label>
      <label className="form-label">Category<select value={category} onChange={e => setCategory(e.target.value)}>{(type === 'income' ? incomeCategories : expenseCategories).map(c => <option key={c}>{c}</option>)}</select></label>
      <label className="form-label">Date<input type="date" value={date} onChange={e => setDate(e.target.value)} required /></label>
      <label className="form-label">Note (optional)<input value={note} onChange={e => setNote(e.target.value)} placeholder="What was this for?" maxLength={120} /></label>
      <button className="submit-button" type="submit">{editingId ? 'Save changes' : 'Save transaction'}</button>
    </form></div>}
  </div>
}