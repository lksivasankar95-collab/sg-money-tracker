import type { CapacitorConfig } from '@capacitor/cli'
const config: CapacitorConfig = {
  appId: 'com.sg.moneytracker',
  appName: 'SG Money Tracker',
  webDir: 'dist',
  bundledWebRuntime: false
}
export default config